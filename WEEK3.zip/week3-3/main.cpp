#include "window.hpp"
#include "line.hpp"
#include "ball.hpp"
#include "muur.hpp"
#include "victim.hpp"

int main(){
   window w( vector( 128, 64 ), 2 );
   muur top(w, vector(0, 0), vector(127, 3), true, vector(1,-1));
   muur right( w, vector( 124,  0 ), vector( 127, 63 ), true, vector(-1,1));
   muur bottom( w, vector(   0, 60 ), vector( 127, 63 ), true, vector(1,-1));
   muur left( w, vector(   0,  0 ), vector(   3, 63 ), true, vector(-1,1));
   ball b( w, vector( 45, 20 ), 9, vector( 5, 2 ));
   victim john(w, vector(63, 20), vector(74, 51));
   
   drawable * objects[] = { &b, &top, &left, &right, &bottom, &john };

   for(;;){
      w.clear();
      for( auto & p : objects ){
         p->draw();
      }
      wait_ms( 200 );
      for( auto & p : objects ){
          p->update();
      }
      for( auto & p : objects ){
         for( auto & other : objects ){
            p->interact( *other );
         } 
      }
   }
}

