// example:
// definition of the functions of a rectangle object

#include "victim.hpp"
#include "rectangle.hpp"

victim::victim( window & w, const vector & start, const vector & end):
   drawable( w, start, end - start),
   end( end ),
   start_x(start.x),
   start_y(start.y),
   end_x(end.x),
   end_y(end.y),
   hit( false )
   {}

void victim::draw(){
    if(start_x <= end_x && start_y <= end_y) {
        rectangle (w, vector(start_x, start_y), vector(end_x, end_y)).draw();
    }
}

void victim::interact( drawable & other ){
   if( this != & other){
      if( overlaps( other )){
          hit = true;
        }
   }
}

void victim::update(){
    if (hit == true){
        if(start_x <= end_x && start_y <= end_y) {
            start_x ++;
            start_y ++;
            end_x --;
            end_y --;
        }
    }
}
