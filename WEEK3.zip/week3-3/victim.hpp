// example:
// declaration of a rectangle object that is contains four line objects

#ifndef VICTIM_HPP
#define VICTIM_HPP

#include "window.hpp"
#include "drawable.hpp"
#include "vector.hpp"
#include "line.hpp"

class victim : public drawable {
protected:
   vector end;
   int start_x;
   int start_y;
   int end_x;
   int end_y;
   bool hit;
public:
   victim( window & w, const vector & start, const vector & end);   
   void draw() override;
   void interact(drawable & other) override;
   void update() override;
};


#endif // RECTANGLE_HPP
